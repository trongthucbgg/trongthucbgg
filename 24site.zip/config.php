<?php
$domain= 'http://domain.com'; // không có / ở cuối
$linktoken= 'http://domain.com/token.txt'; // nên để trong file txt nhé
$id_fb= '1000373727274'; // id nick vip nhé
?>