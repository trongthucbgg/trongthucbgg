<?php
#CHMod cho file coker_log, token.txt là 777 nhé
$dataLog  =  array(
'email' => '', // tài khoản email hoặc sđt facebook 
'pass' => '', // mật khẩu acc
'apps' =>'41158896424', // id apps token 
);

?>

Config xong xóa dòng này và mấy dòng 
// tài khoản email ssđt
// mật khẩu nhé